[
  inputs: [
    "*.{ex,exs}",
    "{config,lib,test}/**/*.{ex,exs}",
    "test/soggy_waffle/weather_api/response_parser_test.exs"
  ],
  line_length: 78
]
