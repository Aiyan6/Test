defmodule ExVCR do
  @moduledoc """
  Record and replay HTTP interactions library for elixir.
  It's inspired by Ruby's VCR, and trying to provide similar functionalities.
  """
end

